var main = new Main();

main.init();
